$(document).ready(function(){
	
	//상단메뉴(데스크탑):주메뉴에 마우스를 댈때 (웹접근성강화)
	$("header li> a").on("focus mouseenter", function(){
		//모든 하위메뉴를 안보이게 한 후
		$("header li nav").stop().slideUp();
		//해당 주메뉴에 대한 하위메뉴만 보이게 한다.
		$(this).next().stop().slideDown();
	});
	
	//하단 드롭다운메뉴 기능
	$("#partner").click(function(){
		$(this).next().slideDown();
	});
	//하단 드롭다운메뉴영역 벗어나면 올라간다.
	$("#partner+nav").mouseleave(function(){
		$(this).slideUp();
	});
	
	
});////////////////끝부분